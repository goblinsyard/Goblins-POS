import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

const BASE = process.env.API_URL ?? 'http://localhost:3000';
let token = '';

async function api<T>(path: string, options: { method?: string; body?: unknown } = {}): Promise<T> {
  const res = await fetch(`${BASE}/api${path}`, {
    method: options.method ?? 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: options.body != null ? JSON.stringify(options.body) : undefined,
  });
  if (!res.ok) {
    throw new Error(`${res.status} ${path}: ${JSON.stringify(await res.json().catch(() => ({})))}`);
  }
  const text = await res.text();
  if (!text) return null as T;
  return JSON.parse(text) as T;
}

describe('Data Import & Export Integration Tests', () => {
  beforeAll(async () => {
    // Authenticate as Owner
    const users = await api<{ id: string; role: { name: string } }[]>('/auth/pin-users');
    const mgr = users.find((u) => u.role.name === 'Owner')!;
    const auth = await api<{ accessToken: string }>('/auth/login/pin', {
      method: 'POST', body: { userId: mgr.id, pin: '9999' },
    });
    token = auth.accessToken;
  });

  it('1. should export current menu catalog and customers list', async () => {
    const menu = await api<any[]>('/admin/export/menu');
    expect(Array.isArray(menu)).toBe(true);
    expect(menu.length).toBeGreaterThan(0);
    expect(menu[0].name).toBeDefined();
    expect(menu[0].items).toBeDefined();

    const customers = await api<any[]>('/admin/export/customers');
    expect(Array.isArray(customers)).toBe(true);
    expect(customers.length).toBeGreaterThan(0);
    expect(customers[0].phone).toBeDefined();
  });

  it('2. should import menu categories, items and modifier groups successfully', async () => {
    const importData = [
      {
        name: 'Goblins Specials',
        nameAr: 'أطباق خاصة',
        sortOrder: 1,
        isActive: true,
        parentCategoryName: null,
        items: []
      },
      {
        name: 'Burgers',
        nameAr: 'برجر',
        sortOrder: 2,
        isActive: true,
        parentCategoryName: 'Goblins Specials',
        items: []
      },
      {
        name: 'Double Cheeseburgers Category',
        nameAr: 'دبل تشيز برجر',
        sortOrder: 3,
        isActive: true,
        parentCategoryName: 'Burgers',
        items: [
          {
            name: 'Double Cheeseburger',
            priceCents: 15000,
            sku: 'GOBLIN-DBL-CHEESE',
            department: 'RESTAURANT',
            modifierGroups: [
              {
                name: 'Sauces',
                minSelect: 0,
                maxSelect: 3,
                modifiers: [
                  { name: 'Ketchup', priceDeltaCents: 0, sortOrder: 1 },
                  { name: 'Special Sauce', priceDeltaCents: 500, sortOrder: 2 }
                ]
              }
            ],
            priceSchedules: [
              {
                name: 'Happy Hour Cheeseburger',
                priceCents: 12000,
                daysOfWeek: [1, 2, 3],
                startTime: '14:00',
                endTime: '17:00',
                isActive: true
              }
            ],
            recipe: {
              name: 'Double Cheeseburger Recipe',
              yieldQty: 1,
              lines: [
                {
                  ingredientName: 'Special Patty',
                  ingredientSku: 'ING-SPEC-PATTY',
                  uomId: 'pc',
                  avgCostCents: 3000,
                  lastCostCents: 3200,
                  quantity: 2,
                  wastePct: 5
                }
              ]
            }
          }
        ]
      }
    ];

    const result = await api<any>('/admin/import/menu', {
      method: 'POST',
      body: importData
    });

    expect(result.success).toBe(true);
    expect(result.categoriesCreated).toBeGreaterThanOrEqual(2);
    expect(result.itemsImported).toBe(1);

    // Verify item was created
    const menu = await api<any[]>('/admin/export/menu');
    
    // Check 3-level hierarchy category linkage
    const catLevel1 = menu.find(c => c.name === 'Goblins Specials')!;
    expect(catLevel1).toBeDefined();
    expect(catLevel1.parentCategoryName).toBeNull();

    const catLevel2 = menu.find(c => c.name === 'Burgers')!;
    expect(catLevel2).toBeDefined();
    expect(catLevel2.parentCategoryName).toBe('Goblins Specials');

    const catLevel3 = menu.find(c => c.name === 'Double Cheeseburgers Category')!;
    expect(catLevel3).toBeDefined();
    expect(catLevel3.parentCategoryName).toBe('Burgers');

    const importedItem = catLevel3.items.find((i: any) => i.name === 'Double Cheeseburger')!;
    expect(importedItem).toBeDefined();
    expect(importedItem.sku).toBe('GOBLIN-DBL-CHEESE');
    expect(importedItem.priceCents).toBe(15000);
    
    // Verify modifier group and sort orders
    expect(importedItem.modifierGroups.length).toBe(1);
    expect(importedItem.modifierGroups[0].name).toBe('Sauces');
    const ketchup = importedItem.modifierGroups[0].modifiers.find((m: any) => m.name === 'Ketchup')!;
    expect(ketchup).toBeDefined();
    expect(ketchup.sortOrder).toBe(1);
    const specSauce = importedItem.modifierGroups[0].modifiers.find((m: any) => m.name === 'Special Sauce')!;
    expect(specSauce).toBeDefined();
    expect(specSauce.sortOrder).toBe(2);

    // Verify price schedules
    expect(importedItem.priceSchedules.length).toBe(1);
    expect(importedItem.priceSchedules[0].name).toBe('Happy Hour Cheeseburger');
    expect(importedItem.priceSchedules[0].priceCents).toBe(12000);

    // Verify recipe and reconstructed ingredient
    expect(importedItem.recipe).toBeDefined();
    expect(importedItem.recipe.name).toBe('Double Cheeseburger Recipe');
    expect(importedItem.recipe.lines.length).toBe(1);
    expect(importedItem.recipe.lines[0].ingredientName).toBe('Special Patty');
    expect(importedItem.recipe.lines[0].uomId).toBe('pc');
    expect(importedItem.recipe.lines[0].avgCostCents).toBe(3000);
    expect(importedItem.recipe.lines[0].lastCostCents).toBe(3200);
  });

  it('3. should import customers and handle duplicates', async () => {
    const importData = [
      { name: 'New Test Customer 1', phone: '+201299999999', email: 'cust1@example.com' },
      { name: 'New Test Customer 2', phone: '+201299999998', tags: ['vip', 'billiards'] }
    ];

    const result = await api<any>('/admin/import/customers', {
      method: 'POST',
      body: importData
    });

    expect(result.success).toBe(true);
    expect(result.importedCount).toBe(2);

    // Patch/update details of customer 1 (should upsert by phone number)
    const updateData = [
      { name: 'New Test Customer 1 (Updated)', phone: '+201299999999', notes: 'Frequent customer' }
    ];

    const result2 = await api<any>('/admin/import/customers', {
      method: 'POST',
      body: updateData
    });
    expect(result2.success).toBe(true);
    expect(result2.importedCount).toBe(1);

    // Verify customer details
    const customers = await api<any[]>('/admin/export/customers');
    const c1 = customers.find(c => c.phone === '+201299999999')!;
    expect(c1).toBeDefined();
    expect(c1.name).toBe('New Test Customer 1 (Updated)');
    expect(c1.notes).toBe('Frequent customer');
  });

  it('4. should erase all demo data and verify database is clean', async () => {
    // Erase demo data
    const result = await api<any>('/admin/db/erase-demo', { method: 'POST' });
    expect(result.success).toBe(true);

    // Verify menu is empty
    const menu = await api<any[]>('/admin/export/menu');
    expect(menu.length).toBe(0);

    // Verify customers are empty
    const customers = await api<any[]>('/admin/export/customers');
    expect(customers.length).toBe(0);
  });

  afterAll(async () => {
    try {
      // Restore database state for subsequent tests
      await execAsync('pnpm.cmd --filter @goblins/api db:seed', { env: { ...process.env, FORCE_RESEED: 'true' } });
    } catch (e) {
      console.error('Failed to re-seed database:', e);
    }
  });
});
