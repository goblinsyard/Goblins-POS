import { useState } from 'react';
import { fmtMoney, t } from '../../lib/i18n';
import { usePos } from '../../lib/store';
import type { MenuItem, ModifierGroup } from '../../lib/types';

function isPasta(name: string, nameAr?: string | null): boolean {
  const n = name.toLowerCase();
  const ar = nameAr ? nameAr.toLowerCase() : '';
  return (
    n.includes('pasta') ||
    n.includes('spaghetti') ||
    n.includes('penne') ||
    n.includes('alfredo') ||
    n.includes('arrabbiata') ||
    n.includes('pomodoro') ||
    n.includes('bolognese') ||
    n.includes('lasagna') ||
    n.includes('fettuccine') ||
    n.includes('macaroni') ||
    ar.includes('مكرونة') ||
    ar.includes('باستا') ||
    ar.includes('سباجيتي')
  );
}

export function ModifierDialog({
  item, onConfirm, onClose,
}: {
  item: MenuItem;
  onConfirm: (modifierIds: string[]) => void;
  onClose: () => void;
}) {
  const { lang } = usePos();
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const isPastaGroup = (g: ModifierGroup) => {
    const name = g.name.toLowerCase();
    const nameAr = g.nameAr ? g.nameAr.toLowerCase() : '';
    return (
      name.includes('pasta') ||
      nameAr.includes('مكرونة') ||
      nameAr.includes('باستا') ||
      g.modifiers.some((m) => isPasta(m.name, m.nameAr))
    );
  };

  const isSidesGroup = (g: ModifierGroup) => {
    const name = g.name.toLowerCase();
    const nameAr = g.nameAr ? g.nameAr.toLowerCase() : '';
    return (
      (name.includes('side') || nameAr.includes('جانب')) &&
      !isPastaGroup(g)
    );
  };

  const isConditionalItem =
    item.modifierGroups.some(({ group }) => isPastaGroup(group)) &&
    item.modifierGroups.some(({ group }) => isSidesGroup(group));

  const selectedMods = item.modifierGroups
    .flatMap(({ group }) => group.modifiers.map(m => ({ m, group })))
    .filter(({ m }) => selected.has(m.id));

  const hasSelectedPasta = selectedMods.some(({ m }) => isPasta(m.name, m.nameAr));
  const hasSelectedSides = selectedMods.some(({ m, group }) => isSidesGroup(group) && !isPasta(m.name, m.nameAr));

  function toggle(groupMax: number, groupModIds: string[], id: string) {
    const next = new Set(selected);
    if (next.has(id)) {
      next.delete(id);
    } else {
      const inGroup = groupModIds.filter((m) => next.has(m));
      if (groupMax === 1) for (const m of inGroup) next.delete(m);
      else if (inGroup.length >= groupMax) return;
      next.add(id);
    }
    setSelected(next);
  }

  const valid = item.modifierGroups.every(({ group }) => {
    const selectedInGroup = group.modifiers.filter((m) => selected.has(m.id));
    const count = selectedInGroup.length;

    let minSelect = group.minSelect;
    let maxSelect = group.maxSelect;

    if (isConditionalItem) {
      const isGroupPasta = isPastaGroup(group);
      const isGroupSides = isSidesGroup(group);

      if (isGroupPasta) {
        if (hasSelectedSides) {
          minSelect = 0;
        } else if (hasSelectedPasta) {
          minSelect = group.maxSelect; // Require exactly maxSelect (1) if pasta is chosen
        }
      } else if (isGroupSides) {
        if (hasSelectedPasta) {
          minSelect = 0;
        } else if (hasSelectedSides) {
          minSelect = group.maxSelect; // Require exactly maxSelect (2) if sides are chosen
        }
      }
    }

    return count >= minSelect && count <= maxSelect;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={onClose}>
      <div
        className="max-h-[85vh] w-full max-w-lg overflow-auto rounded-2xl bg-goblin-900 border border-goblin-800 p-5 text-goblin-50"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="mb-4 text-xl font-bold">{lang === 'ar' && item.nameAr ? item.nameAr : item.name}</h2>
        {item.modifierGroups.map(({ group }) => {
          const selectedInGroup = group.modifiers.filter((m) => selected.has(m.id));

          return (
            <div key={group.id} className="mb-4">
              <h3 className="mb-2 text-sm font-semibold uppercase text-goblin-400">
                {lang === 'ar' && group.nameAr ? group.nameAr : group.name}
                {group.minSelect > 0 && <span className="text-red-400"> *</span>}
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {group.modifiers.map((mod) => {
                  let isDisabled = false;
                  if (isConditionalItem) {
                    const isModPasta = isPasta(mod.name, mod.nameAr);
                    const isModSide = isSidesGroup(group) && !isModPasta;

                    if (isModPasta) {
                      isDisabled = hasSelectedSides || (!selected.has(mod.id) && selectedInGroup.length >= group.maxSelect);
                    } else if (isModSide) {
                      isDisabled = hasSelectedPasta || (!selected.has(mod.id) && selectedInGroup.length >= group.maxSelect);
                    } else {
                      isDisabled = !selected.has(mod.id) && selectedInGroup.length >= group.maxSelect;
                    }
                  } else {
                    isDisabled = !selected.has(mod.id) && selectedInGroup.length >= group.maxSelect;
                  }

                  return (
                    <button
                      key={mod.id}
                      disabled={isDisabled}
                      onClick={() => toggle(group.maxSelect, group.modifiers.map((m) => m.id), mod.id)}
                      className={`rounded-xl p-3 text-start transition-all ${
                        selected.has(mod.id)
                          ? 'bg-goblin-500 text-white'
                          : 'bg-goblin-800 hover:bg-goblin-700 text-goblin-100'
                      } disabled:opacity-30 disabled:pointer-events-none`}
                    >
                      {lang === 'ar' && mod.nameAr ? mod.nameAr : mod.name}
                      {mod.priceDeltaCents > 0 && (
                        <span className="ms-1 block text-sm text-goblin-300">+{fmtMoney(mod.priceDeltaCents, lang)}</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 rounded-xl bg-goblin-800 py-3">
            {t(lang, 'cancel')}
          </button>
          <button
            disabled={!valid}
            onClick={() => onConfirm([...selected])}
            className="flex-1 rounded-xl bg-goblin-500 py-3 font-bold text-white disabled:opacity-40"
          >
            {t(lang, 'add')}
          </button>
        </div>
      </div>
    </div>
  );
}
